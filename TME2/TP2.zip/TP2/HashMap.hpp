//
// Created by yongli on 12/10/2022.
//

#ifndef TP2_HASHMAP_HPP
#define TP2_HASHMAP_HPP

#include <iostream>
#include <chrono>
#include <vector>
#include <string>
#include <utility>
#include <forward_list>

template <typename K, typename V>
class HashMap{

public:
    class Entry{
    public:
        const K key;
        V value;
    };
private:
    typedef std::vector<std::forward_list<Entry>> buckets_t;
    buckets_t buckets;
    size_t sz;
public:
    HashMap(size_t size):sz(0){
        buckets.reserve(size);  // 改变allosize 在操作中不会需要重新申请空间
        for(size_t i = 0; i < size; ++i){
            buckets.emplace_back();
        }
    }
    bool push(const K& key, const V& value){
        size_t index = std::hash<K>()(key) % buckets.size();
        auto l = buckets.at(index);
        size_t exist_list = 0;
        for(auto it = l.begin(); it != l.end(); ++it){
            if(it->key == key){
                exist_list++;
                it->value = value;
                return true;
            }
        }
        if(exist_list == 0){
            l.emplace_front(key, value);
            return false;
        }
    }
    /*
    //std::hash<std::string> hash_string;
    V* get(const K& key){
        size_t index = std::hash<K>()(key) % buckets.size();
        std::forward_list<std::string, int> l = buckets.at(index);
        for(auto it = l.begin(); it != l.end(); ++it){
            if((it->data).key == key){
                return &((it->data).value);
            }else{
                return nullptr;
            }
        }
    }

    size_t size(){
        size_t res = 0;
        for(size_t i = 0; i < buckets.size(); ++i){
            std::forward_list l = buckets.at(i);
            for(auto it = l.begin(), it != l.end; ++it){
                if(it != nullptr){
                    ++res;
                }else{
                    ++i;
                }
            }
        }
        return res;
    }

    void grow(){
        HashMap newH = HashMap(buckets.size()*2);
        for(size_t i = 0; i < buckests.size(); ++I){

        }
    }*/




};

#endif //TP2_HASHMAP_HPP
