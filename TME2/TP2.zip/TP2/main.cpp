
#include "HashMap.hpp"

int main() {

    HashMap<std::string, int> hp = (10);

    hp.push("omg", 10);

    return 0;
}
